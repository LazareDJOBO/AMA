import pandas as pd
import streamlit as st
from sklearn.impute import SimpleImputer 
from sklearn.preprocessing import MinMaxScaler


# Biologique (45%)
# Clinique (35%)
# social (20%)
file = pd.read_csv('Data AI4CKD - Original.csv')
def calcul_scoreComposite(file):

    file = file.drop(index=[306,307,308])
    # print(file.tail())
    file = file[["Age","Sexe","Poids (Kg)","Hb (g/dL)","Enquête Sociale/Alcool","Enquête Sociale/PEC non", "Enquête Sociale/Tabac",
    "TA (mmHg)/Systole","Poul (bpm)","Score de Glasgow (/15)","Créatinine (mg/L)","Urée (g/L)","Na^+ (meq/L)",
    "K^+ (meq/L)","Cl^- (meq/L)","Glycémie à jeun (taux de Glucose)","Diurèse",'Automédication ?']
    ]

    print(file.head())
    file = file.apply(lambda col: col.str.replace(',', '.', regex=False) if col.dtype == 'object' else col)

    #Convertir en numéric
    df_numeric = file.apply(pd.to_numeric, errors='coerce')

    #Récupérer colonne qui n'ont pas pu être convertir
    num_cols = df_numeric.columns[df_numeric.notna().sum() > 0]
    for col in num_cols:
        file[col] = df_numeric[col]

    col_obj = file.select_dtypes(include=["object"]).columns
    file = pd.get_dummies(file, columns=col_obj, drop_first=True)
    col_bool = file.select_dtypes(include=["bool"]).columns
    file[col_bool] = file[col_bool].astype('int64')


    # Séparer continues et binaires
    num_cols_continuous = [col for col in file.columns if set(file[col].dropna().unique()) - {0,1}]
    bin_cols = [col for col in file.columns if set(file[col].dropna().unique()) <= {0,1}]

    # Imputation pour colonnes continues
    cont_imputer = SimpleImputer(strategy="median")
    file[num_cols_continuous] = cont_imputer.fit_transform(file[num_cols_continuous])

    # Imputation pour colonnes binaires
    bin_imputer = SimpleImputer(strategy="most_frequent")  # ou strategy="constant", fill_value=0
    file[bin_cols] = bin_imputer.fit_transform(file[bin_cols])

    f = [col for col in file.columns if 'Diurèse' in col]
    print(f)


    def calcule_DFG(sexe,age,creatinine):
        #convertion en mg/dL
        cr = creatinine/10

        # 2. Paramètres de la formule CKD-EPI 2021 (sans facteur ethnique)
        kappa = 0.7 if sexe == '0' else 0.9
        alpha = -0.241 if sexe == '0' else -0.302
        constant = 142
        femelle_adj = 1.012 if sexe == '0' else 1.0
        
        # Calcul
        dfg = constant * min(cr/kappa, 1)**alpha * max(cr/kappa, 1)**-1.200 * (0.9938**age) * femelle_adj
        return dfg

    file = file[file['Créatinine (mg/L)'] > 0]
    DFG = []

    for row in file.itertuples():
        # row.NomDeLaColonne permet d'accéder aux données
        # print(row)
        valeur = calcule_DFG(row.Sexe_M, row.Age, row._7)
        DFG.append(valeur)
        
    file['DFG_calcule'] = DFG

    # fonction pour la normalisation des varibles
    def normalize(series):
        return series.rank(pct=True) * 100

    def normalize_inverse(series):
        return (1 - series.rank(pct=True)) * 100

    # Sous score biologique
    file['bio_n'] = (
        normalize_inverse(file['DFG_calcule']) +
        normalize(file['Urée (g/L)']) +
        normalize(file['K^+ (meq/L)']) +
        normalize(file['Na^+ (meq/L)']) +
        normalize_inverse(file['Hb (g/dL)']) +
        normalize(file['Glycémie à jeun (taux de Glucose)'])
    )/6


    clin_vars = [
        'Age',
        'TA (mmHg)/Systole',
        'Poul (bpm)',
        'Score de Glasgow (/15)',
        'Poids (Kg)',
        'Diurèse_Non quantifiée',
        'Diurèse_Oligurie',
        'Diurèse_Préservée'
    ]

    file['score_clinique'] = file[clin_vars].apply(normalize).mean(axis=1)


    soc_vars = [
        'Enquête Sociale/Alcool',
        'Enquête Sociale/PEC non',
        'Automédication ?_Oui',
        'Automédication ?_RAS'
      
       ]

    file['score_social'] = file[soc_vars].mean(axis=1) * 100

    file['score_composite'] = (
        0.45 * file['bio_n'] +
        0.35 * file['score_clinique'] +
        0.20 * file['score_social']    
    )

    def classer(score):
        if score < 30: return "Faible"
        elif score < 60: return "Modéré"
        else: return "Élevé"

    file['niveau_risque'] = file['score_composite'].apply(classer)

    return file

